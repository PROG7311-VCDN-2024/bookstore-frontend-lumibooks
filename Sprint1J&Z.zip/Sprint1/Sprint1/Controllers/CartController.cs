﻿using Microsoft.AspNetCore.Mvc;
using Sprint1.Models;
using System.Linq;
using System.Security.Claims;

namespace Sprint1.Controllers
{
    public class CartController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CartController(ApplicationDbContext context)
        {
            _context = context;
        }

        private string GetCurrentUserId()
        {
            return User.FindFirstValue(ClaimTypes.NameIdentifier);
        }

        public IActionResult Index()
        {
            var userId = GetCurrentUserId();
            var cart = _context.Carts.FirstOrDefault(c => c.UserId == userId);
            return View(cart);
        }

        [HttpPost]
        public IActionResult AddToCart(int bookId)
        {
            var userId = GetCurrentUserId();
            var cart = _context.Carts.FirstOrDefault(c => c.UserId == userId);

            if (cart == null)
            {
                cart = new Cart { UserId = userId };
                _context.Carts.Add(cart);
            }

            var existingCartItem = cart.CartItems.FirstOrDefault(item => item.BookId == bookId);

            if (existingCartItem != null)
            {
                existingCartItem.Quantity++;
            }
            else
            {
                cart.CartItems.Add(new CartItem { BookId = bookId, Quantity = 1 });
            }

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
