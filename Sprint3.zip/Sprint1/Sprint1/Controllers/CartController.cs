﻿using Microsoft.AspNetCore.Mvc;

namespace Sprint1.Controllers
{
    public class CartController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddToCart(int bookId)
        {
            // Add logic to add the specified book to the user's cart
            return RedirectToAction("Index", "Cart");
        }

        public IActionResult RemoveFromCart(int bookId)
        {
            // Add logic to remove the specified book from the user's cart
            return RedirectToAction("Index", "Cart");
        }

        public IActionResult ClearCart()
        {
            // Add logic to clear all items from the user's cart
            return RedirectToAction("Index", "Cart");
        }
    }
}
