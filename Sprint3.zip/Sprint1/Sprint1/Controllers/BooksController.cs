﻿using Microsoft.AspNetCore.Mvc;
using Sprint1.Models;
using System.Collections.Generic;

namespace Sprint1.Controllers
{
    public class BooksController : Controller
    {
        // GET: /Books/Index
        public IActionResult Index()
        {
            // Retrieve books from the database or any other source
            var books = GetBooksFromDatabase();

            return View(books);
        }

        // Example method to retrieve books (replace with your actual implementation)
        private List<Book> GetBooksFromDatabase()
        {
            // Simulate fetching books from a database
            var books = new List<Book>
            {
                new Book { Id = 1, Title = "Book 1", Author = "Author 1", Price = 10.99m },
                new Book { Id = 2, Title = "Book 2", Author = "Author 2", Price = 12.99m },
                new Book { Id = 3, Title = "Book 3", Author = "Author 3", Price = 14.99m }
            };

            return books;
        }
    }
}
